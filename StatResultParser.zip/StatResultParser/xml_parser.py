try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET
import csv
import os


def stat_result_parser():
    all_stat_xml = 'allstats1_Result_0000_modified.xml'
    result_file_name = 'StatResults.csv'
    unknown_value = "NA"
    stat_result_path = './/statResult'
    stat_result_headers = ("valuationSpecName",
                           "baseBenchmarkPairName",
                           "statisticName",
                           "drilldownName",
                           "positionId",
                           "positionName",
                           "holdingId",
                           "holdingName",
                           "securityType",
                           "customDimensionName",
                           "horizon",
                           "resultValue")

    __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))

    tree = ET.parse(os.path.join(__location__, all_stat_xml))
    root = tree.getroot()

    with open(os.path.join(__location__, result_file_name), 'w+') as csv_file:

        csv_writer = csv.writer(csv_file, delimiter=',')

        csv_writer.writerow(stat_result_headers)

        for stat_result in root.findall(stat_result_path):
            stat_result_values = []

            for column in stat_result_headers:
                tag_path = './/' + column

                if stat_result.find(tag_path) is None:
                    stat_result_values.append(unknown_value)
                else:
                    stat_result_values.append(stat_result.find(tag_path).text)

            csv_writer.writerow(stat_result_values)


if __name__ == '__main__':
    stat_result_parser()
